import babel from "@rollup/plugin-babel";
import commonjs from '@rollup/plugin-commonjs';
import resolve from "@rollup/plugin-node-resolve";
import pkg from "./package.json";

// Excluded dependencies
const EXTERNAL = [...Object.keys(pkg.devDependencies), Object.keys(pkg.peerDependencies)];

export default {
  input: ["src/index.ts"],
  output: {
    dir: "dist",
    sourcemap: true,
    format: "esm",
    preserveModules: true
  },
  globals: {
    "React": "react"
  },
  plugins: [
    commonjs(),
    resolve(
      {extensions: [".js", ".jsx", ".ts", ".tsx"]},
    ),
    babel({
      extensions: [".js", ".jsx", ".ts", ".tsx"],
      babelHelpers: "runtime",
      include: [".js", ".jsx", ".ts", ".tsx"].map(ext => `src/**/*${ext}`),
      configFile: './babel.config.js'
    })
  ],
  external: EXTERNAL
};