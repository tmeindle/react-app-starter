const Component=()=><div>component</div>;
export default Component;