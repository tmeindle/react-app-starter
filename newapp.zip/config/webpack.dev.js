const path = require('path');
const webpack = require('webpack');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const CircularDependencyPlugin = require('circular-dependency-plugin');
const ReactRefreshWebpackPlugin = require('@pmmmwh/react-refresh-webpack-plugin');

module.exports = {
  mode: 'development',
  devtool: 'eval-source-map',
  target: 'web',
  entry: {
    app: [
      path.join(process.cwd(), 'src/index.js')
    ],
  },

  output: {
    path: path.join(process.cwd(), 'dist'),
    publicPath: '/',
    filename: '[name].js',
    chunkFilename: '[name].chunk.js'
  },

  module: {
    rules: [
      // JavaScript: Use Babel to transpile JavaScript files
      {
        test: /\.jsx?$/,
        exclude: /node_modules/,
        use: {
          loader: "babel-loader",
          options: {
            presets: ['@babel/preset-env'],
            plugins: [require.resolve('react-refresh/babel')]
          }
          
        }
      },
      {
        test: /\.(s?css)$/,
        use: [
          'style-loader',
          {loader: 'css-loader', options: {sourceMap: true, importLoaders: 1}},
          {loader: 'sass-loader', options: {sourceMap: true}},
        ],
        exclude: /\.module\.(s?css)$/,
      },
      {
        test: /\.module\.(s?css)$/,
        use: [
          'style-loader',
          {loader: 'css-loader', options: {sourceMap: true, importLoaders: 1, modules: true}},
          {loader: 'sass-loader', options: {sourceMap: true}},
        ],
      },

      // copy fonts to build folder
      {test: /\.(woff(2)?|eot|ttf|otf|)$/, type: 'asset/resource'},
      
      // inline small images (10kb or less)
      {
        test: /\.(ico|gif|png|jpg|jpeg|svg)$/, 
        type: 'asset',
        parser: {
          dataUrlCondition: {
            maxSize: 10 * 1024 // 10kb
          }
        }
      },
    ],
  },

  plugins: [
    new HtmlWebpackPlugin({
      title: 'Webpack Boilerplate',
      //favicon: '/images/favicon.png',
      template: path.join(process.cwd(), 'src/index.html'), // template file
      filename: 'index.html', // output file
    }),
    new CircularDependencyPlugin({
      exclude: /node_modules/,
      failOnError: false,
    }),
    new ReactRefreshWebpackPlugin(),
  ],

  devServer: {
    contentBase: path.join(process.cwd(), 'dist'),
    //compress: true,
    disableHostCheck: true, //IE 11 work-around
    hot: true,
    https: true,
    historyApiFallback: true,
    port: 3000,
    watchOptions: {
      poll: 1000,
      ignored: ['mode_modules'],
    },
    //open: true,
  },

  performance: {
    hints: false,
  },

  resolve: {
    modules: ['node_modules', 'src'],
    extensions: ['.mjs', '.js', '.jsx'],
  },
}
