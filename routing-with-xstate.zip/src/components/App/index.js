import React, { useState } from 'react';
import { createBrowserHistory } from 'history';
import { Machine, matchesState, assign, send } from 'xstate';

import useRoutedMachine from '../../routed-machine/useRoutedMachine';

const machineConfig = {
  id: 'light',
  initial: 'green',
  states: {
    green: {
      initial: 'init',
      states: {
        init: {
          after: {
            10000: {
              target: '#light.yellow',
            },
          },
          meta: {
            path: '/green',
          },
        },
      },
    },
    yellow: {
      after: {
        10000: '#light.red',
      },
      meta: {
        path: '/yellow/:timer?',
      },
    },
    red: {
      on: {
        TIMER: 'green',
      },
      meta: {
        path: '/red',
      },
    },
  },
};

const machine = Machine(machineConfig);
const history = createBrowserHistory();

const App = () => {
  const [state, send, service] = useRoutedMachine(machine, history);

  return (
    <div>
      <button type="button" onClick={() => { send('TIMER'); }}>TIMER</button>
      <button type="button" onClick={() => { history.push('/green'); }}>green</button>
      <button type="button" onClick={() => { history.push('/yellow'); }}>yellow</button>
      <button type="button" onClick={() => { history.push('/red'); }}>red</button>
    </div>
  );
};

export default App;
