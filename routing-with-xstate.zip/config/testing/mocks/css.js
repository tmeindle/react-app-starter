module.exports = 'CSS_MOCK';
