import cloneDeep from 'lodash/cloneDeep';
import { assign } from 'xstate';
import { routeChangedEvent, matchURI, getRoutes } from './utilities';

const resolve = (routes, uri) => {
  for (let i = 0; i < routes.length; i++) {
    const route = routes[i];
    const matched = matchURI(route[1], uri);
    if (matched) return matched.params;
  }
  return undefined;
};

const addRouterEvents = (configObj) => {
  const routes = getRoutes(configObj);
  const config = cloneDeep(configObj);
  const machineId = config.id ?? '(machine)';

  if (!config.on) {
    config.on = {};
  } else {
    config.on = { ...config.on };
  }

  const given = config.on?.[routeChangedEvent] ? config.on[routeChangedEvent] : [];
  const on = Array.isArray(given) ? given : [given];

  on.push({
    cond: (context, event) => event.dueToStateTransition,
    actions: assign((context, event) => ({
      location: event.location,
      match: resolve(routes, event.location),
    })),
  });

  for (let i = 0; i < routes.length; i++) {
    const route = routes[i];
    on.push({
      target: `#${machineId}.${route[0].join('.')}`,
      cond: (_context, event) => event.dueToStateTransition === false && event.route && event.route === route[1],
      actions: assign((context, event) => ({
        location: event.location,
        match: matchURI(route[1], event.location.pathname).params,
      })),
    });
  }

  config.on[routeChangedEvent] = on;
  return config;
};

export default addRouterEvents;

