const path = require('path');
const webpack = require('webpack');
const HtmlWebpackPlugin = require('html-webpack-plugin');

const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const CssMinimizerPlugin = require('css-minimizer-webpack-plugin');
const CompressionPlugin = require("compression-webpack-plugin");

module.exports = {
  mode: 'production',
  target: 'web',
  entry: {
    app: [
      path.join(process.cwd(), 'src/index.js')
    ],
  },

  output: {
    path: path.join(process.cwd(), 'dist'),
    publicPath: '/',
    filename: '[name].[chunkhash].js',
    chunkFilename: '[name].[chunkhash].chunk.js'
  },

  module: {
    rules: [
      // JavaScript: Use Babel to transpile JavaScript files
      {
        test: /\.jsx?$/,
        exclude: /node_modules/,
        use: {
          loader: "babel-loader",
          options: {
            presets: ['@babel/preset-env'],
          }
        }
      },
      {
        test: /\.(s?css)$/,
        use: [
          MiniCssExtractPlugin.loader,
          {loader: 'css-loader', options: {sourceMap: true, importLoaders: 1}},
          {loader: 'sass-loader', options: {sourceMap: true}},
        ],
        exclude: /\.module\.(s?css)$/,
      },
      {
        test: /\.module\.(s?css)$/,
        use: [
          MiniCssExtractPlugin.loader,
          {loader: 'css-loader', options: {sourceMap: true, importLoaders: 1, modules: true}},
          {loader: 'sass-loader', options: {sourceMap: true}},
        ],
      },

      // copy fonts to build folder
      {test: /\.(woff(2)?|eot|ttf|otf|)$/, type: 'asset/resource'},
      
      // inline small images (10kb or less)
      {
        test: /\.(ico|gif|png|jpg|jpeg|svg)$/, 
        type: 'asset',
        parser: {
          dataUrlCondition: {
            maxSize: 10 * 1024 // 10kb
          }
        }
      },
    ],
  },

  plugins: [
    new HtmlWebpackPlugin({
      title: 'Webpack React App',
      //favicon: '/images/favicon.png',
      template: path.join(process.cwd(), 'src/index.html'), // template file
      filename: 'index.html', // output file
    }),
    new CompressionPlugin({
      algorithm: 'gzip',
      test: /\.jsx?$|\.s?css$|\.html$/,
      threshold: 10240,
      minRatio: 0.8,
    }),
  ],
  
  optimization: {
    minimize: true,
    minimizer: [new CssMinimizerPlugin(), "..."],
    // Once your build outputs multiple chunks, this option will ensure they share the webpack runtime
    // instead of having their own. This also helps with long-term caching, since the chunks will only
    // change when actual code changes, not the webpack runtime.
    runtimeChunk: {
      name: 'runtime',
    },
  },
  
  performance: {
  },

  resolve: {
    modules: ['node_modules', 'src'],
    extensions: ['.mjs', '.js', '.jsx'],
  },
}
