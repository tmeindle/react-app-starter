module.exports = require('./config/webpack.prod');
