module.exports = 'MEDIA_MOCK';
