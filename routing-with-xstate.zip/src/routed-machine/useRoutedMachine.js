import { useEffect, useMemo } from 'react';
import { compile } from 'path-to-regexp';
import { Machine } from 'xstate';
import { useMachine } from '@xstate/react';
import { routeChangedEvent, matchURI, getRoutes } from './utilities';
import addRouterEvents from './addRouterEvents';

const findPathRecursive = (stateNode) => {
  let actual = stateNode;
  while (actual.parent) {
    if (actual.meta && actual.meta.path) {
      return actual.meta.path;
    }
    actual = actual.parent;
  }
  return undefined;
};

const getStateNode = (service, state) => {
  const strings = state.toStrings();
  const stateNode = service.machine.getStateNodeByPath(strings[strings.length - 1]);
  return stateNode;
};

const matchUriToState = (service, routes, location) => {
  let matchingRoute;
  for (let i = 0; i < routes.length; i++) {
    const route = routes[i];

    const matched = matchURI(route[1], location.pathname);
    if (matched) {
      matchingRoute = route;
      break;
    }
  }
  return matchingRoute;
};

const useRoutedMachine = (machine, history, options = {}, initialContext) => {
  const routedMachineConfig = useMemo(() => addRouterEvents(machine.config), [machine.config]);
  const [state, send, service] = useMachine(Machine(routedMachineConfig), options, initialContext);
  const routes = useMemo(() => getRoutes(machine.config), [machine.config]);

  useEffect(() => {
    const initialRoute = matchUriToState(service, routes, history.location);
    const currentState = service.state.toStrings().slice(-1);
    if (initialRoute && currentState !== initialRoute[0].join('.')) {
      service.send({ type: routeChangedEvent, dueToStateTransition: false, route: initialRoute[1], location: history.location });
    }

    service.onTransition((newState) => {
      const stateNode = getStateNode(service, newState);
      const path = findPathRecursive(stateNode);
      const toPath = compile(path, { encode: encodeURIComponent });
      const uri = toPath(newState.context.match);
      if (history.location.pathname !== uri) {
        history.push(uri);
      }
    });

    const unlisten = history.listen(() => {
      const matchingRoute = matchUriToState(service, routes, history.location);
      if (matchingRoute && currentState !== matchingRoute[0].join('.')) {
        service.send({ type: routeChangedEvent, dueToStateTransition: false, route: matchingRoute[1], location: history.location });
      } else {
        service.send({ type: routeChangedEvent, dueToStateTransition: true, route: matchingRoute[1], location: history.location });
      }
    });

    return () => {
      unlisten();
    };
  }, [history, routes, service]);

  return [state, send, service];
};

export default useRoutedMachine;
