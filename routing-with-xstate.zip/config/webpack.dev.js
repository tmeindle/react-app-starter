const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const CircularDependencyPlugin = require('circular-dependency-plugin');
const ReactRefreshWebpackPlugin = require('@pmmmwh/react-refresh-webpack-plugin');

module.exports = {
  mode: 'development',
  devtool: 'eval-source-map',
  target: 'web',

  entry: {
    app: [
      path.join(process.cwd(), 'src/index.js'),
    ],
  },

  output: {
    path: path.join(process.cwd(), 'build'),
    publicPath: '/',
    filename: '[name].js',
    chunkFilename: '[name].chunk.js',
  },

  devServer: {
    contentBase: path.join(process.cwd(), 'build'),
    // compress: true,
    disableHostCheck: true, // IE 11 work-around
    hot: true,
    https: true,
    historyApiFallback: true,
    port: 3000,
    watchOptions: {
      poll: 1000,
      ignored: ['mode_modules'],
    },
    // open: true,
  },

  module: {
    rules: [
      // Transpile JavaScript files using Babel
      {
        test: /\.jsx?$/,
        exclude: /node_modules/,
        use: {
          loader: 'babel-loader',
          options: {
            presets: ['@babel/preset-env'],
          },

        },
      },
      // Transpile scss and load css files
      {
        test: /\.(s?css)$/,
        use: [
          'style-loader',
          { loader: 'css-loader', options: { sourceMap: true, importLoaders: 1 } },
          { loader: 'sass-loader', options: { sourceMap: true } },
        ],
        exclude: /\.module\.(s?css)$/,
      },
      // Transpile scss and load css module files
      {
        test: /\.module\.(s?css)$/,
        use: [
          'style-loader',
          { loader: 'css-loader', options: { sourceMap: true, importLoaders: 1, modules: true } },
          { loader: 'sass-loader', options: { sourceMap: true } },
        ],
      },

      // copy fonts to build folder
      { test: /\.(woff(2)?|eot|ttf|otf|)$/, type: 'asset/resource' },

      // inline small images (10kb or less)
      {
        test: /\.(ico|gif|png|jpg|jpeg|svg)$/,
        type: 'asset',
        parser: {
          dataUrlCondition: {
            maxSize: 10 * 1024, // 10kb
          },
        },
      },
    ],
  },

  plugins: [
    new ReactRefreshWebpackPlugin(),
    new HtmlWebpackPlugin({
      title: 'Webpack Boilerplate',
      // favicon: '/images/favicon.png',
      template: './src/index.html',
      filename: './index.html', // output file
    }),
    new CircularDependencyPlugin({
      exclude: /node_modules/,
      failOnError: false,
    }),
  ],

  performance: {
    hints: false,
  },

  resolve: {
    modules: ['node_modules', 'src'],
    extensions: ['.mjs', '.js', '.jsx'],
  },
};
