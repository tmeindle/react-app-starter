module.exports = {
  presets: [
    [
      '@babel/preset-env', 
      {
        loose :true,
      }
    ],
    [
      "@babel/preset-react",
      {
        runtime: 'automatic',
      }
    ],
    '@babel/preset-typescript',  
  ],
  plugins: [   
    [
      '@babel/plugin-proposal-class-properties',
      {
        loose: true,
      }
    ],
    ["@babel/plugin-proposal-private-methods", { loose: true }],
    [
      'babel-plugin-polyfill-regenerator',
      {
        method: 'usage-pure',
      }
    ],
    'babel-plugin-annotate-pure-calls',
    'babel-plugin-macros',
    'babel-plugin-lodash',
    '@babel/plugin-transform-runtime'
  ],
}