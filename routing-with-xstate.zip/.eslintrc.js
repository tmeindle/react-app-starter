const restrictedGlobals = require('confusing-browser-globals');

module.exports = {
  parser: 'babel-eslint',
  extends: [
    'plugin:react/recommended',
    // 'plugin:redux-saga/recommended',
    'plugin:import/errors',
    'plugin:import/warnings',
    'airbnb',
    'airbnb/hooks',
  ],
  plugins: [
    'import',
    'prettier',
    // 'redux-saga',
    'react',
    'react-hooks',
  ],
  env: {
    jest: true,
    browser: true,
    node: true,
    es6: true,
  },
  parserOptions: {
    ecmaVersion: 6,
    sourceType: 'module',
    ecmaFeatures: {
      jsx: true,
    },
  },
  settings: {
    'import/resolver': {
      node: {},
      webpack: {
        config: './webpack.config.js',
      },
    },
  },
  rules: {
    'arrow-body-style': 'off', // consistent return for functional components
    'import/no-extraneous-dependencies': ['error', {
      devDependencies: ['**/*.test.js', 'config/*.js', '.eslintrc.js', 'webpack.config.js'],
    }], // ensures dependencies are identified correctly in package.json
    'import/prefer-default-export': 'off', // would need to override this in too many places where default exports aren't needed (i.e. models, constants, utilities, etc)
    'max-len': 'off',
    'no-plusplus': ['error', { allowForLoopAfterthoughts: true }], // Allow ++ in loop definitions only
    'no-use-before-define': 'off',
    'object-curly-newline': 'off',
    'react/jsx-first-prop-new-line': ['error', 'multiline'], // All props should be on their own line if atleast one is
    'react/jsx-filename-extension': 'off', // don't enforce .jsx file extensions
    'react/require-default-props': 'off', // don't enforce deprecated defaultProps (use functions default args)
    'no-multiple-empty-lines': ['error', { max: 1, maxEOF: 1, maxBOF: 0 }],
    'eol-last': ['error', 'always'],
    'no-restricted-globals': ['error'].concat(restrictedGlobals),
  },
};
