// import 'core-js/stable';
// import 'regenerator-runtime/runtime';

global.fetch = require('jest-fetch-mock');

console.warn = () => {}; // eslint-disable-line no-console
