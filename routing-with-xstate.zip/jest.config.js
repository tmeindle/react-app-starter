module.exports = {
  coveragePathIgnorePatterns: [
    'src/index.js',
  ],
  collectCoverageFrom: [
    'src/**/*.js',
    '!src/**/*.test.js', // no need to test the tests
  ],
  coverageThresholds: {
    global: {
      statements: 0,
      branches: 0,
      functions: 0,
      lines: 0,
    },
  },
  moduleDirectories: ['node_modules', 'src'],
  moduleMapper: {
    '.*\\.(css|less|styl|scss|sass)$': '<rootDir>/config/testing/mocks/css.js',
    '.*\\.(jpg|jpeg|png|gif|eot|otf|webp|svg|ttf|woff|woff2|mp4|webm|wav|mp3|m4a|aac|oga)$': '<rootDir>/config/testing/mocks/media.js',
  },
  setupFilesAfterEnv: ['<rootDir>/config/testing/setup/jest-setup.js'],
  setupFiles: ['jest-localstorage-mock', '<rootDir>/config/testing/setup/enzyme-setup.js'],
  testRegex: '.*\\.test\\.js$',
};
