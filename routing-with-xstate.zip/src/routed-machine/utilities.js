import { match } from 'path-to-regexp';
import { Machine } from 'xstate';
import { getStateNodes } from '@xstate/graph';

export const routeChangedEvent = 'route-changed';

export const matchURI = (path, uri) => {
  return (!path) ? {} : match(path, { decode: decodeURIComponent })(uri);
};

export const getRoutes = (configObj) => {
  const nodes = getStateNodes(Machine(configObj));
  const routes = [];

  for (let i = 0; i < nodes.length; i++) {
    const node = nodes[i];
    if (node.meta && node.meta.path) {
      routes.push([node.path, node.meta.path]);
    }
  }

  return routes;
};

