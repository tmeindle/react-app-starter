const path = require('path');
const webpack = require('webpack');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const CompressionPlugin = require('compression-webpack-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const CssMinimizerPlugin = require('css-minimizer-webpack-plugin');
const { BundleAnalyzerPlugin } = require('webpack-bundle-analyzer');
const TerserPlugin = require('terser-webpack-plugin');

module.exports = {
  mode: 'production',
  devtool: 'source-map',
  target: 'web',

  entry: {
    app: [
      path.join(process.cwd(), 'src/index.js'),
    ],
  },

  output: {
    path: path.join(process.cwd(), 'build'),
    publicPath: '/',
    filename: '[name].[contenthash].js',
    chunkFilename: '[name].[contenthash].chunk.js',
  },

  module: {
    rules: [
      // Transpile JavaScript files using Babel
      {
        test: /\.jsx?$/,
        exclude: /node_modules/,
        use: {
          loader: 'babel-loader',
          options: {
            presets: ['@babel/preset-env'],
          },

        },
      },
      // Transpile scss and load css files
      {
        test: /\.(s?css)$/,
        use: [
          MiniCssExtractPlugin.loader,
          { loader: 'css-loader', options: { sourceMap: true, importLoaders: 1 } },
          { loader: 'sass-loader', options: { sourceMap: true } },
        ],
        exclude: /\.module\.(s?css)$/,
      },
      // Transpile scss and load css module files
      {
        test: /\.module\.(s?css)$/,
        use: [
          MiniCssExtractPlugin.loader,
          { loader: 'css-loader', options: { sourceMap: true, importLoaders: 1, modules: true } },
          { loader: 'sass-loader', options: { sourceMap: true } },
        ],
      },

      // copy fonts to build folder
      { test: /\.(woff(2)?|eot|ttf|otf|)$/, type: 'asset/resource' },

      // inline small images (10kb or less)
      {
        test: /\.(ico|gif|png|jpg|jpeg|svg)$/,
        type: 'asset',
        parser: {
          dataUrlCondition: {
            maxSize: 10 * 1024, // 10kb
          },
        },
      },
    ],
  },

  plugins: [
    new HtmlWebpackPlugin({
      title: 'Webpack React App',
      template: path.join(process.cwd(), 'src/index.html'), // template file
      filename: 'index.html', // output file
    }),
    new CompressionPlugin({
      algorithm: 'gzip',
      test: /\.jsx?$|\.s?css$|\.html$/,
      threshold: 10240,
      minRatio: 0.8,
    }),
    new BundleAnalyzerPlugin({
      analyzerMode: process.env.ANALYZE_BUNDLE ? 'server' : 'disabled', // only use analyzer when requested
    }),
  ],

  optimization: {
    minimize: true,
    minimizer: [new CssMinimizerPlugin(), new TerserPlugin({
      terserOptions: {
        format: {
          comments: false,
        },
      },
      extractComments: false,
    })],
    runtimeChunk: {
      name: 'runtime',
    },
    splitChunks: {
      chunks: 'all',
      maxSize: 256 * 1024,
      automaticNameDelimiter: '.',
      cacheGroups: {
        pollyfill: {
          name: 'polyfill',
          test: /[\\/]node_modules[\\/](corejs|regenerator-runtime)[\\/]/,
          priority: 0,
        },
        defaultVendor: {
          name: 'modules',
          test: /[\\/]node_modules[\\/](?!(corejs|regenerator-runtime|react.*|reselect|redux.*|styled-components|prop-types))[\\/]/,
          priority: -2,
          reuseExistingChunk: true,
        },
        react: {
          name: 'react',
          test: /[\\/]node_modules[\\/](react.*|reselect|redux.*|styled-components|prop-types)[\\/]/,
          priority: -4,
          reuseExistingChunk: true,
        },
        default: {
          name: 'app',
          priority: -6,
          reuseExistingChunk: true,
        },
      },
    },
  },

  performance: {
    assetFilter: (assetFilename) => !/(\.map$)|(^(main\.|favicon\.))/.test(assetFilename),
  },

  resolve: {
    modules: ['node_modules', 'src'],
    extensions: ['.mjs', '.js', '.jsx'],
  },
};
