import React from 'react';

const App = () => {
    return <div>hello world</div>;
}

export default App;