import React from 'react';

//function App() {
export const App = () => {
return (
    <div className="App">
      Hello World!!
    </div>
  );
}

export default App;
